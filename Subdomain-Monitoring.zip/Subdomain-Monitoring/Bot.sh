while true;
do
  subfinder -d swisspass.ch,sbb.ch -all -silent | anew "Domains/SBB - Domains.txt" | python3 Bot.py "sbb";
  subfinder -d tomorrowland.com -all -silent | anew "Domains/Tomorrowland - Domains.txt" | python3 Bot.py "tomorrowland";
  cat Domains/*.txt > Domains.txt;
  nuclei -list Domains.txt -silent -rl 25 -t Nuclei-Templates | notify -pc vulnerability-bot.yaml;
  sleep 21600;
done