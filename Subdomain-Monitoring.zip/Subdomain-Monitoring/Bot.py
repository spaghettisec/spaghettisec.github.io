#!/usr/bin/python3
from subprocess import run, check_output
import sys

def run_notification(domain: str, result: str, config: str) -> None:
    for i in range(1, 3):
        run(f"echo \"{domain}\" | notify -pc Configs/{config}-bbp-{i}.yaml", shell=True)
        run(f"echo \"{result}\" | notify -pc Configs/{config}-bbp-{i}.yaml", shell=True)
        
if __name__ == "__main__":
    if sys.stdin.isatty():
        print("echo \"www.example.com\" | python3 Bot.py")
    else:
        httpx_command = "httpx -target {} -silent -no-color -status-code -content-length -content-type -title -cname -ip -tech-detect -location -timeout 60"
        domains = sys.stdin.read().strip().split("\n")
        for domain in domains:
            result = check_output(httpx_command.format(domain), shell=True).decode("utf-8", errors="ignore").replace("\n", "").replace("\"", "").strip()
            if len(sys.argv) > 1:
                if sys.argv[1] == "tomorrowland":
                    run_notification(domain, result, "tomorrowland")
                elif sys.argv[1] == "sbb":
                    run_notification(domain, result, "sbb")